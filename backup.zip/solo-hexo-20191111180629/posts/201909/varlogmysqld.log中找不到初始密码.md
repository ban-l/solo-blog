title: /var/log/mysqld.log 中找不到初始密码
date: '2019-09-09 21:15:45'
updated: '2019-09-09 21:15:45'
tags: [Linux]
permalink: /articles/2019/09/09/1568034945349.html
---
![](https://img.hacpai.com/bing/20171127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## /var/log/mysqld.log 中找不到初始密码

原因：原来安装过的 MySQL 有残留的数据
解决：[CentOS 7 卸载 MySQL 5.7](http://www.lbb.pub/articles/2019/09/09/1568028549819.html)

**删除完成后，重启 mysqld 服务**

```
systemctl restart mysqld
```
重新找回初始密码
```
grep 'temporary password' /var/log/mysqld.log
```

**ok ！**

