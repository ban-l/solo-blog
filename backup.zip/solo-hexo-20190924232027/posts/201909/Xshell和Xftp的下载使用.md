title: Xshell 和Xftp 的下载使用
date: '2019-09-09 12:49:41'
updated: '2019-09-09 12:54:55'
tags: [工具]
permalink: /articles/2019/09/09/1568004581840.html
---
![](https://img.hacpai.com/bing/20190312.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## Xshell 和Xftp下载安装
Xshell 和Xftp 是收费的，可以申请 家庭/学校免费，只需要一个有效的电子邮件地址，下载链接将发送到你的邮箱
[Xshell和Xftp下载地址](https://www.netsarang.com/zh/free-for-home-school/)

**使用Xshell控制云服务器，使用Xftp和电脑传输文件。**

**Xshell**：Xshell 可以在 Windows 界面下用来访问远端不同系统下的服务器，从而比较好的达到远程控制终端的目的。除此之外，其还有丰富的外观配色方案以及样式选择。
**Xftp**：Xftp 是一个功能强大的 SFTP、FTP 文件传输软件。使用了 Xftp 以后，MS Windows 用户能安全地在 UNIX/Linux 和 Windows PC 之间传输文件。

下载之后，直接默认配置安装就行，也可以修改安装路径。

## Xshell的使用

 - 运行 Xshell，新建会话，填写你的公网ip

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190909101108833.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0x1Y2l1c18=,size_16,color_FFFFFF,t_70)

 - 填写用户名密码，就是你服务器的实例密码，忘记密码记得重置。
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019090910153089.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0x1Y2l1c18=,size_16,color_FFFFFF,t_70)
 - 连接成功，会显示如下页面
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190909101759206.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0x1Y2l1c18=,size_16,color_FFFFFF,t_70)

## Xftp的使用
和Xshell一样，新建会话，填写ip，用户名密码。
当然也可以在Xhell里直接点击运行，它会自动连接。
如下图
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190909102436271.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0x1Y2l1c18=,size_16,color_FFFFFF,t_70)
ok！
