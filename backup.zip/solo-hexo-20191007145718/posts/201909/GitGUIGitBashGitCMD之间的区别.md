title: Git GUI,Git Bash,Git CMD之间的区别
date: '2019-09-09 21:20:39'
updated: '2019-09-09 21:20:39'
tags: [Git]
permalink: /articles/2019/09/09/1568035239881.html
---
![](https://img.hacpai.com/bing/20190622.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Git Bash：

Bash，Unix shell的一种，Linux与Mac OS X v10.4都将它作为默认shell。
Git Bash就是一个shell，是Windows下的命令行工具，可以执行Linux命令。
Git Bash是基于CMD的，在CMD的基础上增添一些新的命令与功能。所以建议在使用的时候，用Bash更加方便。

# Git CMD：

（命令行提示符）是Windows操作系统上的命令行解释程序。当你在Windows上安装git并且习惯使用命令行时，可以使用cmd来运行git命令。

# Git GUI：

基本上针对那些不喜欢黑屏（即命令行）编码的人。它提供了一个图形用户界面来运行您喜欢的git命令。
