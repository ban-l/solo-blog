title: CentOS 7 安装 MySQL 5.7
date: '2019-09-09 21:14:09'
updated: '2019-10-08 08:51:58'
tags: [Linux, MySQL]
permalink: /articles/2019/09/09/1568034849783.html
---
![](https://img.hacpai.com/bing/20181103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 卸载

 - 如果之前安装了MySQl，要先卸载，很简单，几步而已。[卸载MySQL](http://www.lbb.pub/articles/2019/09/09/1568028549819.html)

## 安装

 1. 下载YUM源
```
wget http://dev.mysql.com/get/mysql57-community-release-el7-8.noarch.rpm
```
 2. 安装 MySQL源

```
yum localinstall mysql57-community-release-el7-8.noarch.rpm
```

 3. 检查 MySQL 源是否安装成功

```
yum repolist enabled | grep "mysql.*-community.*"
```

 4. 安装 MySQL
```
yum -y install mysql-community-server
```
 5. 查看MySQL版本

```
mysql -V
```
若出现如下信息表示安装成功

```
[root@lbb ~]# mysql -V
mysql  Ver 14.14 Distrib 5.7.27, for Linux (x86_64) using  EditLine wrapper
```

 6. 启动 MySQL 服务
```
  systemctl start mysqld
```
 7. 查看 MySQL 的启动状态

```
  systemctl status mysqld
```

 8. 设置 MySQL 服务开机自启动

```
  systemctl enable mysqld
```

 9.查看初始密码
  MySQL 安装完成之后，在 /var/log/mysqld.log 文件中给 root 生成了一个默认密码。查看 /var/log/mysqld.log 文件，获取并记录 root 用户的初始密码

```
# grep 'temporary password' /var/log/mysqld.log
2019-04-28T06:50:56.674085Z 1 [Note] A temporary password is generated for root@localhost: 3w)WqGlM7-o,
```
如果找不到初始密码可以看这里：[/var/log/mysqld.log 中找不到初始密码](https://blog.csdn.net/Lucius_/article/details/100674394)

 10. 重置密码

登录
```
mysql -uroot -p你找到的密码
```
重置
```
ALTER USER 'root'@'localhost' IDENTIFIED BY '你的新密码';
```
新密码长度为8至30个字符，必须同时包含大小写英文字母、数字和特殊符号。特殊符号可以是()` ~!@#$%^&*-+=|{}[]:;‘<>,.?/

 11. 远程访问 MySQL

**新建用户**
不建议 root 账号允许远程登录，所以新建一个用户允许远程连接。
```
CREATE USER 'username'@'host' IDENTIFIED BY 'password';
```
**username**：你将创建的用户名 非必须情况下，不太建议使用 root 用户
**host**：指定该用户在哪个主机上可以登陆，如果是本地用户可用 localhost，如果想让该用户可以从任意远程主 - 机登陆，可以使用通配符 %
**password**：该用户的登陆密码，密码可以为空，如果为空则该用户可以不需要密码登陆服务器。

**创建用户test**
```
CREATE USER 'test'@'%' IDENTIFIED BY '你的密码';
```
**授权**

```
GRANT privileges ON databasename.tablename TO 'username'@'host'；
```
**privileges**：用户的操作权限，如 SELECT，INSERT，UPDATE 等，如果要授予所的权限则使用 ALL
**databasename**：数据库名
**tablename**：表名，如果要授予该用户对所有数据库和表的相应操作权限则可用表示，如.*

**授予用户test权限**
```
grant all on *.* to 'test'@'%'IDENTIFIED BY '你的密码';
```
刷新
```
flush privileges;
```

接下来就能操作数据库了
**ok ！**

