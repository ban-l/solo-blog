title: CentOS 7 安装 JDK
date: '2019-09-09 21:11:56'
updated: '2019-10-08 08:53:00'
tags: [JDK]
permalink: /articles/2019/09/09/1568034716894.html
---
![](https://img.hacpai.com/bing/20190223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1.下载解压
下载
![根据自己电脑选择不同版本](https://imgconvert.csdnimg.cn/aHR0cHM6Ly91cGxvYWQtaW1hZ2VzLmppYW5zaHUuaW8vdXBsb2FkX2ltYWdlcy83OTI5NDMxLWFlOWZkNjZhOWM2NTM3OGQucG5n?x-oss-process=image/format,png)

使用 [Xftp](https://blog.csdn.net/Lucius_/article/details/100653141)把文件传输到虚拟机，在当前目录解压
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190909085447971.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0x1Y2l1c18=,size_16,color_FFFFFF,t_70)
```
tar -xvf jdk-8u221-linux-x64.tar.gz
```
也可以解压到其他目录，自行决定

```
tar -xvf jdk-8u221-linux-x64.tar.gz  /usr/java
```


## 2.配置环境变量
在root权限下进入到 /etc/profile文件
```
vi /etc/profile
```
敲大写字母G，定位到文件末尾，在末尾加上环境变量

```
# java environment 
export JAVA_HOME=/usr/java/jdk1.8.0_221
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export JRE_HOME=$JAVA_HOME/jre
```

## 3.更新
修改完 profile 文件，执行生效命令：
```
source /etc/profile
```

## 4.测试安装成功
查看java版本
```
  java  -version

```
出现以下情况配置完成

```
java version "1.8.0_221"
Java(TM) SE Runtime Environment (build 1.8.0_221-b11)
Java HotSpot(TM) 64-Bit Server VM (build 25.221-b11, mixed mode)
```

安装完成

