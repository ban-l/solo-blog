title: war包方式部署solo博客
date: '2019-09-09 21:18:37'
updated: '2019-09-09 21:18:37'
tags: [Linux]
permalink: /articles/2019/09/09/1568035117743.html
---
![](https://img.hacpai.com/bing/20190219.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

solo，一款小而美的博客系统，GitHub：https://github.com/b3log/solo

## 环境和文件准备

 - 服务器：用的阿里云服务器，系统是CentOS 7.3 64 位。
 - JDK：1.8
 - Tomcat： 9.0.24
 - MySQL：5.7
 - solo：solo-v3.6.4.war

介绍两款工具，接下来会用到，**Xshell**和**Xftp**
[Xshell 和 Xftp 的下载使用](https://blog.csdn.net/Lucius_/article/details/100653141)
使用Xshell控制云服务器，使用Xftp和电脑传输文件。

## 安装JDK
[Centos7 安装 JDK](https://blog.csdn.net/Lucius_/article/details/100641634)
## 安装Tomcat

 - 下载Tomcat

```
wget https://www-us.apache.org/dist/tomcat/tomcat-9/v9.0.24/bin/apache-tomcat-9.0.24.tar.gz
```

 - 解压

```
tar -xvf apache-tomcat-9.0.24.tar.gz
```

 - 修改server.xml文件，通过80端口访问，访问时默认端口会隐藏

```
 <Connector port="80" protocol="HTTP/1.1" connectionTimeout="20000" redirectPort="8443" />
```

## 安装MySQL
[Centos7 安装 MySQL 5.7](https://blog.csdn.net/Lucius_/article/details/100670957)

建库（库名 solo，字符集使用 utf8mb4，排序规则 utf8mb4_general_ci)
```
CREATE DATABASE  `solo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

## 部署 Solo

 - 下载war包

```
wget https://github.com/b3log/solo/releases/download/v3.6.4/solo-v3.6.4.war
```

 - 将Tomcat下 /webapps/ROOT 目录清空，将war包解压到里面

```
tar -xvf solo-v3.6.4.war
```

 - 修改配置文件 latke.properties 和 local.properties

 先进入文件路径
```
cd /usr/local/tomcat/apache-tomcat-9.0.24/webapps/ROOT/WEB-INF/classes
```
vi命令编辑配置文件
```
vi latke.properties
```
配置 Solo 的访问域名端口和模式
serverHost=你的已解析的域名，serverPort默认为80

```
#### Server ####
# Browser visit protocol
serverScheme=http
serverHost=www.lbb.pub
serverPort=
```
配置数据库
```
vi local.properties
```
配置MySQl用户名和密码
jdbc.username=用户名
jdbc.password=密码
```
#### MySQL runtime ####
runtimeDatabase=MYSQL
jdbc.username=root
jdbc.password=123456
jdbc.driver=com.mysql.cj.jdbc.Driver
jdbc.URL=jdbc:mysql://localhost:3306/root?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC
```

配置完成之后，就可以启动Tomcat,然后通过你的域名访问博客了。
 
 **ok ！**

